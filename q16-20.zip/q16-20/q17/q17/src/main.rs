use std::io;

fn main() {
    println!("Enter a string:");

    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .expect("Failed to read line");

    let input = input.trim(); 

    if !input.is_empty() {
        let first_char = &input[0..1];
        let last_char = &input[input.len() - 1..];

        println!("First character: {}", first_char);
        println!("Last character: {}", last_char);
    } else {
        println!("The input string is empty.");
    }
}
