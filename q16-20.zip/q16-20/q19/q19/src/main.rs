fn reverse_sentence(input: &str) -> String {
    let reversed_words: Vec<&str> = input.split_whitespace().rev().collect();
    let reversed_sentence = reversed_words.join(" ");
    reversed_sentence
}

fn main() {
    let sentence = "My name is Hanzala Hashmi.";

    let reversed = reverse_sentence(sentence);

    println!("Original sentence: {}", sentence);
    println!("Reversed sentence: {}", reversed);
}
