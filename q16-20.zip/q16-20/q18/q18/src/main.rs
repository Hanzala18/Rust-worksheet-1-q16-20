fn count_substring_occurrences(main_string: &str, substring: &str) -> usize {
    let mut count = 0;
    let mut start = 0;

    while let Some(pos) = main_string[start..].find(substring) {
        count += 1;
        start += pos + substring.len();
    }

    count
}

fn main() {
    let main_string = "hi, hi, hi, every1";
    let substring = "hi";

    let occurrences = count_substring_occurrences(main_string, substring);

    println!("The substring '{}' appears {} times in the main string.", substring, occurrences);
}
