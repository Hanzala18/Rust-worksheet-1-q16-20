fn find_longest<'a>(str1: &'a str, str2: &'a str) -> &'a str {
    if str1.len() >= str2.len() {
        str1
    } else {
        str2
    }
}

fn main() {
    let string1 = "Hanzala";
    let string2 = "Hanzala Hashmi";

    let longest = find_longest(string1, string2);

    println!("The longest string is: {}", longest);
}
